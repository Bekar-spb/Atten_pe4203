/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * Atten_lcd_control @ main.c
  *  : Управление дисплеем и опрос энкодера
  *  программная заготовка для аттенюатора "Нептун"
  ******************************************************************************
  * чтобы добавить Library нужно прописать путь в properts для .c & .h получается две
  * строчки в include patch
  * Это классный пример на удивление дисплей завелся, толком не понимаю как это работает
  *  но факт меня очень порадовал. Завтра можно подключить энкодер
  *
  *  20.01.26 в общем GPT телеграмовский прислал код передачи управляющих сигналов по
  * serial я прошил его получилось криво на delay-ях но в целом все сигналы clk и data я вижу
  * нужно использовать таймер без него не получится предварительно научиться отправлять в uart
  * содержимое регистра "data".
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <stdbool.h>
#include "lcd1602_i2c_lib.h"

extern char lcd1602_tx_buffer[40];
uint8_t flag_key1_press = 1;   // кнопка
uint32_t time_key1_press = 0;  // антидребезг

float output_value = 0.0f;    	// значение для вывода в lcd
uint8_t flag;
bool polar_flag = false;   // флаг полярности вращения
bool flag_batton = false;          // флаг срабатывания кнопки

uint32_t Delay = 100;   // было 600

unsigned long T1 ;
int32_t prevCounter = 0;  // для энкодера
volatile uint16_t button_delay; // регистр времени задержки для кнопки  

volatile int encoder_position = 0;
volatile uint32_t last_interrupt_time = 0;
#define DEBOUNCE_DELAY 5 // 5 мс

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim9;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C1_Init(void);
static void MX_TIM1_Init(void);
static void MX_TIM9_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_TIM3_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/*------------------------------Отладка по SWO--------------------------------*/
int _write(int file, uint8_t *ptr, int len) {

	for (int DataIdx = 0; DataIdx < len; DataIdx++) {
		ITM_SendChar(*ptr++);
	}
	return len;
}
/*------------------------------Отладка по SWO--------------------------------*/


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */



  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
//  void SendByteToPE4314(uint8_t data);
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C1_Init();
  MX_TIM1_Init();
  MX_TIM9_Init();
  MX_USART2_UART_Init();
  MX_TIM3_Init();
  /* USER CODE BEGIN 2 */
  	  HAL_Delay(100);
  	  lcd1602_Init();
  	void SendByteToPE4314(uint8_t data);  // Процедура отправки data clk le
  	void SendByteToUART(uint8_t data);    // Функция для отправки байта в UART
  	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET);  // принудительный ноль
  	// задаю начальное значение счетчика:
  	     __HAL_TIM_SET_COUNTER(&htim1, 65542);    // было так 65570

  	 // не забываем включить таймер!
  	      HAL_TIM_Encoder_Start(&htim1, TIM_CHANNEL_ALL);  // запуск Энкодера
  	    HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);  // запуск pwm на Tim3 pin PB4
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

	  if(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_10) == GPIO_PIN_RESET && flag_key1_press) // подставил свой пин РА10
	  {
	    flag_key1_press = 0;                           // кнопка отпущена
	  // 	действие на нажатие
	  //   HAL_UART_Transmit(&huart1, (uint8_t*)"KEY_PRESS\n", 10, 1000);
	  //   flag_transmit = true;                         // установить флаг
	    time_key1_press = HAL_GetTick();
	  }

	  if(!flag_key1_press && (HAL_GetTick() - time_key1_press) > 300)
	  {
	    flag_key1_press = 1;						// кнопка нажата
	    flag_batton = true;                         // установить флаг
	  }

	  // Функция отправки байта через UART
	  void SendByteToUART(uint8_t data) {
	      char buffer[20];
	      int len = snprintf(buffer, sizeof(buffer), "Data sent: 0x%02X\n", data); // Форматируем строку в шестнадцатеричной форме
	      HAL_UART_Transmit(&huart2, (uint8_t*)buffer, len, HAL_MAX_DELAY); // Отправка данных по UART
	  }


	  	void SendByteToPE4314(uint8_t data) {       //   *** Функция отправки одного байта в PE4314 ***

	  		  		HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13); 	// пин синий светодиод

	  	  				    // Установка LE низким уровнем
	  	        	  	 HAL_Delay(25);
	  	  			     HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET); // LE = 0

	  	  			 // Передача данных
	  	  			     for (int i = 0; i < 6; i++) {

	  	  			 // Установка DATA
	  	  			        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, (data & (1 << (5 - i))) ? GPIO_PIN_SET : GPIO_PIN_RESET);
	  	  			        HAL_Delay(50);

	  	  			 // Генерация тактового сигнала
	  	  			        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, GPIO_PIN_SET); // CLK = 1
	  	  			    	HAL_Delay(50);

	  	  			        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, GPIO_PIN_RESET); // CLK = 0
	  	  			   	  	HAL_Delay(50);

	  	  			         	 	 	 	 	 }
	  	  		     // Установка LE высоким уровнем
	  	  			     HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_RESET); // pin 6 запаздывает почему-то принудительно уст."0"
	  	  			     HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_SET);    // LE = 1
	  	  			         HAL_Delay(25);
	  		  			  				}




	  if (HAL_GetTick() - T1 >= Delay) {     				// начало основного цикла обязательно должно быть
	  			T1 = HAL_GetTick();

	  	//		HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13); 	// пин синий светодиод

	  			if (flag == 0) {   							 // *** процедура опроса энкодера ***
	  				 flag = 1;

	  				lcd1602_SetCursor(0, 0);

	  				int currCounter = __HAL_TIM_GET_COUNTER(&htim1);
	  				    currCounter = 32767 + ((currCounter - 1) & 0xFFFF) / 2;    // не понимаю как, но в общем работает


	  				  if(currCounter > 32768/2) {
	  				          // Преобразуем значения счетчика из:
	  				          //  ... 32766, 32767, 0, 1, 2 ...
	  				          // в значения:
	  				          //  ... -2, -1, 0, 1, 2 ...
	  				          currCounter = currCounter - 32768; 			// было 32768
	  				      }
	  				 if (currCounter > prevCounter) {
	  					    polar_flag = true;                    // Вращение по часовой
	  					  	 prevCounter = currCounter;    		  // запоминаем предыдущее значение
	  		                             	     }
	  				     if (currCounter < prevCounter){
	  				    	 polar_flag = false;                   // Вращение против часовой
	  				    	  prevCounter = currCounter;    	   // запоминаем предыдущее значение
	  				     	 	 	 	 	 	 	 	}


	  				if (flag == 1) {
	  								flag = 2;
	  						snprintf (lcd1602_tx_buffer, sizeof(lcd1602_tx_buffer), "Encod = %d           ", currCounter);   //
	  									lcd1602_Print_text(lcd1602_tx_buffer);
	  									output_value = currCounter *0.5f ;     // конвертация счетчика в значения 0,5

	  									if (output_value > 31.5f) {
	  									            output_value = 31.5f;
	  									        }

	  					}

	  				if (flag == 2) {                 // отображение значений во второй строке

            		lcd1602_SetCursor(0, 1);
            		sprintf(lcd1602_tx_buffer, "Atten = -%.1f         ", output_value);  //  counter_float
            		lcd1602_Print_text(lcd1602_tx_buffer);

	  				flag = 3;
                       	}

	  				if (flag == 3) {
	  						flag = 4;

	  						uint8_t command = 0;

	  						    // Перевод значения в 7-битный код (0 .. 31 дБ)
	  						    command = (uint8_t)((currCounter ) ); // Коррекция +1 для режима

	  						    SendByteToPE4314(command); 					// Отправка команд управления Data, Clk, Le
	  						    SendByteToUART(command);                    // Отправка команды через UART для контроля
	  					if (flag_batton == true)								// если кнопка была  нажата
	  							{
	  						flag_batton = false;  //
	  							}

	  			//		HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13); 	// пин синий светодиод
	  		            	}

	  				if (flag == 4) {    // просто запасной цикл вдруг понадобится
	  					flag = 0;

	  				       }

	  					}

	  			}



  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 50;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 100000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_Encoder_InitTypeDef sConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 0;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 65535;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  sConfig.EncoderMode = TIM_ENCODERMODE_TI1;
  sConfig.IC1Polarity = TIM_ICPOLARITY_RISING;
  sConfig.IC1Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC1Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC1Filter = 0;
  sConfig.IC2Polarity = TIM_ICPOLARITY_RISING;
  sConfig.IC2Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC2Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC2Filter = 0;
  if (HAL_TIM_Encoder_Init(&htim1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 50;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 11;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_PWM_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */
  HAL_TIM_MspPostInit(&htim3);

}

/**
  * @brief TIM9 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM9_Init(void)
{

  /* USER CODE BEGIN TIM9_Init 0 */

  /* USER CODE END TIM9_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_SlaveConfigTypeDef sSlaveConfig = {0};

  /* USER CODE BEGIN TIM9_Init 1 */

  /* USER CODE END TIM9_Init 1 */
  htim9.Instance = TIM9;
  htim9.Init.Prescaler = 0;
  htim9.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim9.Init.Period = 65535;
  htim9.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim9.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim9) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim9, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sSlaveConfig.SlaveMode = TIM_SLAVEMODE_DISABLE;
  sSlaveConfig.InputTrigger = TIM_TS_ITR0;
  if (HAL_TIM_SlaveConfigSynchro(&htim9, &sSlaveConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM9_Init 2 */

  /* USER CODE END TIM9_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7, GPIO_PIN_RESET);

  /*Configure GPIO pin : PC13 */
  GPIO_InitStruct.Pin = GPIO_PIN_13;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : PA5 */
  GPIO_InitStruct.Pin = GPIO_PIN_5;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PA6 PA7 */
  GPIO_InitStruct.Pin = GPIO_PIN_6|GPIO_PIN_7;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : PA10 */
  GPIO_InitStruct.Pin = GPIO_PIN_10;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
/*
void EXTI_A_Callback() {
    uint32_t current_time = HAL_GetTick();
    // Дребезг: пропускаем, если прошло мало времени
    if (current_time - last_interrupt_time < DEBOUNCE_DELAY) {
        return;
    }
    last_interrupt_time = current_time;

    // Читаем B в момент фронта на A
    if (HAL_GPIO_ReadPin(ENCODER_B_PORT, ENCODER_B_PIN) == GPIO_PIN_SET) {
        encoder_position++; // Вращение по часовой
    } else {
        encoder_position--; // Вращение против часовой
    }
}
*/
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
